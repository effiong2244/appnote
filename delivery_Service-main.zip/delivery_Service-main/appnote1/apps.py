from django.apps import AppConfig


class Appnote1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appnote1'
